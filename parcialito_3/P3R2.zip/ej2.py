# 2. Escribir una función que reciba por parámetro dos pilas y modifique su
# contenido de manera que los elementos de la primer pila queden en la
# segunda, y los de la segunda en la primera manteniendo el orden original de
# los elementos. Como estructuras auxiliares, se pueden utilizar únicamente
# pilas y/o colas.


from tda import Pila, Cola

# Completar la siguiente funcion
def intercambiar_pilas(pila1, pila2):
    pass


p1 = Pila([4, 5, 6, 9])
p2 = Pila([1, 3])

intercambiar_pilas(p1, p2)

assert p1 == Pila([1, 3])
assert p2 == Pila([4, 5, 6, 9])
