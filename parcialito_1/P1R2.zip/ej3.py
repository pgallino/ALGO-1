# 3. Escribir una función `ajustar_linea()` que recibe una cadena y un número `n`, 
# y devuelva una lista con la cadena original partida en multiples cadenas de tamaño `n`.
# La unica cadena con tamaño menor a `n` es la ultima (si no hay suficientes caracteres).
# Ejemplos:
# ajustar_linea('Algoritmos', 5)
#   => ['Algor', 'itmos']
# ajustar_linea('Algoritmos y programacion I', 8)
#   => ['Algoritm', 'os y pro', 'gramacio', 'n I']


# Completar la siguiente funcion
def ajustar_linea(cadena, n):
    pass


assert ajustar_linea('Algoritmos', 5) == ['Algor', 'itmos']
assert ajustar_linea('Algoritmos y programacion I', 8) == ['Algoritm', 'os y pro', 'gramacio', 'n I']