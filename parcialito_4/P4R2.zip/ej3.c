// 3. Escribir en C una función que reciba un número secreto `n` (de tipo `int`) y le
// pregunte un número al usuario. Si el número ingresado es distinto a `n`, debe
// indicarle si es mayor o menor y volver a pedirle otro número. Si es igual, debe
// felicitar al usuario, mostrar en cuántos intentos adivinó y devolver dicha cantidad.


// Completar la siguiente funcion
int pedir_numero_secreto(int secreto) {

}


int main() {
    int n = 15;
    pedir_numero_secreto(n);
}
