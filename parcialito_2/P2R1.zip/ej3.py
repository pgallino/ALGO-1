# Se quiere modelar un perchero para colgar ropa. Se pide crear las clases `Perchero` y `Prenda` tal que se se puedan ejecutar 
# las siguientes líneas de código y se obtengan los resultados especificados:
# >>> p = Perchero(3)
# >>> p.colgar(Prenda('camisa', 1))
# >>> p.colgar(Prenda('pantalon', 1))
# >>> pantalon = p.sacar('pantalon')
# >>> print(pantalon)
# Pantalon: 1
# >>> p.sacar('remera')
# ValueError: No se encontró la prenda
# >>> p.espacio_disponible()
# 2
# >>> p.colgar(Prenda('campera', 3))
# ValueError: No hay espacio para colgar la prenda
# El constructor de `Perchero` recibe la cantidad de espacio total disponible, y el de `Prenda` recibe el nombre de la prenda y cuánto espacio ocupa

# Escribir el codigo debajo de esta linea

# Pruebas
p = Perchero(3)
p.colgar(Prenda('camisa', 1))
p.colgar(Prenda('pantalon', 1))
pantalon = p.sacar('pantalon')
assert(str(pantalon) == 'pantalon: 1')
hay_excepcion = True
try:
    p.sacar('remera')
    hay_excepcion = False
except ValueError:
    pass
assert hay_excepcion, "una excepcion no fue lanzada"
assert(p.espacio_disponible() == 2)
hay_excepcion = True
try:
    p.colgar(Prenda('campera', 3))
    hay_excepcion = False
except ValueError:
    pass
assert hay_excepcion, "una excepcion no fue lanzada"
